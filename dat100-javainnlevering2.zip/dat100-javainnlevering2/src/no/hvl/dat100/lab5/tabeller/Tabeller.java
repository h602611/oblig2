package no.hvl.dat100.lab5.tabeller;

public class Tabeller {

	// a)
	public static void skrivUt(int[] tabell) {

		for (int i = 0; i < tabell.length; i++) {
			System.out.print(tabell[i]);
		}

	}

	// b)
	public static String tilStreng(int[] tabell) {

		 String resultat= "[";
	        for (int i=0; i < tabell.length; i++) {
	            resultat += tabell[i];
	            if (i != tabell.length -1) {
	                resultat+=",";
	            }
	        }
	        return resultat + "]";
	}

	// c)
	public static int summer(int[] tabell) {
		int sum = 0;
		for (int i = 0; i < tabell.length; i++) {
            
            sum += tabell[i];
        }
            return sum;
	}

	// d)
	public static boolean finnesTall(int[] tabell, int tall) {

		boolean svar = false;
        for (int i = 0; i < tabell.length; i++) {
            if (tall == tabell[i]) {
               svar = true;
            }
            
        }
        return svar;
	}

	// e)
	public static int posisjonTall(int[] tabell, int tall) {

		 int posisjon = -1;
	        for (int i = 0; i < tabell.length; i++) {
	            if (tall == tabell[i]) {
	                posisjon = i;
	            }
	        }
	        return posisjon;

	}

	// f)
	public static int[] reverser(int[] tabell) {

		int[] reverse = new int[tabell.length];
        for (int i = 0; i < tabell.length; i++) {
            reverse[tabell.length - 1 - i] += tabell[i];
        }
        return reverse;
		
	}

	// g)
	public static boolean erSortert(int[] tabell) {

		 boolean checkin = true;
	        for (int i = 1; i < tabell.length; i++) {
	            if (tabell[i] < tabell[i - 1]) {
	                checkin = false;
	            }
	        }
	        return checkin;
	}

	// h)
	public static int[] settSammen(int[] tabell1, int[] tabell2) {


	}
}
